﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordChecker_Куделя_Никита
{
    public class PasswordChecker
    {
        public static bool ValidatePassword(string password)
        {
            return true;
        }
    }
}
