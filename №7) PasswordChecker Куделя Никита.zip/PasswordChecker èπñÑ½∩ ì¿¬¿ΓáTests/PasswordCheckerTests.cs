﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PasswordChecker_Куделя_Никита;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordChecker_Куделя_Никита.Tests
{
    [TestClass()]
    public class PasswordCheckerTests
    {
        [TestMethod()]
        public void Check_8Symbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASqw12$$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_4Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "Aq1$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_PasswordWithlowerSymbolsReturnsTure()
        {
            // Arrange.
            string password = "ASDq123$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual (expected, actual);

        }

        [TestMethod()]
        public void Check_PasswordWithlowerSymbolsReturnsFalse()
        {
            // Arrange.
            string password = "ASDq123$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);

        }
    }
}