﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI_калькулятор
{
    public partial class UserControl1: UserControl
    {
        float ind; // у него это index
        float r;
        float V;
        public UserControl1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            r = float.Parse(rost.Text);
            V = float.Parse(ves.Text);
            r = r / 100;
            ind = V / (r * r);
            index.Text = ind.ToString("N");
            trackBar1.Value = (int)ind; 
        }
    }
}
