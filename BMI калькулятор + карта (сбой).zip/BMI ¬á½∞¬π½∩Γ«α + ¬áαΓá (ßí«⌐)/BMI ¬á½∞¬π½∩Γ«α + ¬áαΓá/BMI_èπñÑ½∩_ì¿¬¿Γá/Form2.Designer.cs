﻿namespace BMI_Куделя_Никита
{
    partial class Map
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Map));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxfirst = new System.Windows.Forms.PictureBox();
            this.pictureBoxsecond = new System.Windows.Forms.PictureBox();
            this.pictureBoxthird = new System.Windows.Forms.PictureBox();
            this.pictureBoxforth = new System.Windows.Forms.PictureBox();
            this.pictureBoxfifth = new System.Windows.Forms.PictureBox();
            this.pictureBoxsix = new System.Windows.Forms.PictureBox();
            this.pictureBoxseven = new System.Windows.Forms.PictureBox();
            this.pictureBoxeight = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.marafonLabel = new System.Windows.Forms.Label();
            this.labelMedical = new System.Windows.Forms.Label();
            this.pictureBoxMedical = new System.Windows.Forms.PictureBox();
            this.labelInformation = new System.Windows.Forms.Label();
            this.pictureBoxInformation = new System.Windows.Forms.PictureBox();
            this.labelToilets = new System.Windows.Forms.Label();
            this.pictureBoxTuilets = new System.Windows.Forms.PictureBox();
            this.labelEnergy = new System.Windows.Forms.Label();
            this.pictureBoxEnergy = new System.Windows.Forms.PictureBox();
            this.labelDrinks = new System.Windows.Forms.Label();
            this.pictureBoxDrinks = new System.Windows.Forms.PictureBox();
            this.nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxsecond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxthird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxforth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfifth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxsix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxseven)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(35, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(638, 597);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBoxStart1
            // 
            this.pictureBoxStart1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStart1.Image")));
            this.pictureBoxStart1.Location = new System.Drawing.Point(260, 65);
            this.pictureBoxStart1.Name = "pictureBoxStart1";
            this.pictureBoxStart1.Size = new System.Drawing.Size(66, 63);
            this.pictureBoxStart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart1.TabIndex = 1;
            this.pictureBoxStart1.TabStop = false;
            this.pictureBoxStart1.Click += new System.EventHandler(this.pictureBoxStart1_Click);
            // 
            // pictureBoxStart2
            // 
            this.pictureBoxStart2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStart2.Image")));
            this.pictureBoxStart2.Location = new System.Drawing.Point(296, 539);
            this.pictureBoxStart2.Name = "pictureBoxStart2";
            this.pictureBoxStart2.Size = new System.Drawing.Size(66, 63);
            this.pictureBoxStart2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart2.TabIndex = 2;
            this.pictureBoxStart2.TabStop = false;
            this.pictureBoxStart2.Click += new System.EventHandler(this.pictureBoxStart2_Click);
            // 
            // pictureBoxStart3
            // 
            this.pictureBoxStart3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStart3.Image")));
            this.pictureBoxStart3.Location = new System.Drawing.Point(109, 266);
            this.pictureBoxStart3.Name = "pictureBoxStart3";
            this.pictureBoxStart3.Size = new System.Drawing.Size(66, 63);
            this.pictureBoxStart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart3.TabIndex = 3;
            this.pictureBoxStart3.TabStop = false;
            this.pictureBoxStart3.Click += new System.EventHandler(this.pictureBoxStart3_Click);
            // 
            // pictureBoxfirst
            // 
            this.pictureBoxfirst.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxfirst.Image")));
            this.pictureBoxfirst.Location = new System.Drawing.Point(397, 46);
            this.pictureBoxfirst.Name = "pictureBoxfirst";
            this.pictureBoxfirst.Size = new System.Drawing.Size(59, 58);
            this.pictureBoxfirst.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxfirst.TabIndex = 5;
            this.pictureBoxfirst.TabStop = false;
            this.pictureBoxfirst.Click += new System.EventHandler(this.pictureBoxfirst_Click);
            // 
            // pictureBoxsecond
            // 
            this.pictureBoxsecond.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxsecond.Image")));
            this.pictureBoxsecond.Location = new System.Drawing.Point(464, 216);
            this.pictureBoxsecond.Name = "pictureBoxsecond";
            this.pictureBoxsecond.Size = new System.Drawing.Size(59, 59);
            this.pictureBoxsecond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxsecond.TabIndex = 6;
            this.pictureBoxsecond.TabStop = false;
            this.pictureBoxsecond.Click += new System.EventHandler(this.pictureBoxsecond_Click);
            // 
            // pictureBoxthird
            // 
            this.pictureBoxthird.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxthird.Image")));
            this.pictureBoxthird.Location = new System.Drawing.Point(451, 337);
            this.pictureBoxthird.Name = "pictureBoxthird";
            this.pictureBoxthird.Size = new System.Drawing.Size(59, 56);
            this.pictureBoxthird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxthird.TabIndex = 7;
            this.pictureBoxthird.TabStop = false;
            this.pictureBoxthird.Click += new System.EventHandler(this.pictureBoxthird_Click);
            // 
            // pictureBoxforth
            // 
            this.pictureBoxforth.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxforth.Image")));
            this.pictureBoxforth.Location = new System.Drawing.Point(594, 468);
            this.pictureBoxforth.Name = "pictureBoxforth";
            this.pictureBoxforth.Size = new System.Drawing.Size(63, 60);
            this.pictureBoxforth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxforth.TabIndex = 8;
            this.pictureBoxforth.TabStop = false;
            this.pictureBoxforth.Click += new System.EventHandler(this.pictureBoxforth_Click);
            // 
            // pictureBoxfifth
            // 
            this.pictureBoxfifth.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxfifth.Image")));
            this.pictureBoxfifth.Location = new System.Drawing.Point(366, 555);
            this.pictureBoxfifth.Name = "pictureBoxfifth";
            this.pictureBoxfifth.Size = new System.Drawing.Size(55, 57);
            this.pictureBoxfifth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxfifth.TabIndex = 9;
            this.pictureBoxfifth.TabStop = false;
            this.pictureBoxfifth.Click += new System.EventHandler(this.pictureBoxfifth_Click);
            // 
            // pictureBoxsix
            // 
            this.pictureBoxsix.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxsix.Image")));
            this.pictureBoxsix.Location = new System.Drawing.Point(172, 489);
            this.pictureBoxsix.Name = "pictureBoxsix";
            this.pictureBoxsix.Size = new System.Drawing.Size(61, 64);
            this.pictureBoxsix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxsix.TabIndex = 10;
            this.pictureBoxsix.TabStop = false;
            this.pictureBoxsix.Click += new System.EventHandler(this.pictureBoxsix_Click);
            // 
            // pictureBoxseven
            // 
            this.pictureBoxseven.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxseven.Image")));
            this.pictureBoxseven.Location = new System.Drawing.Point(116, 388);
            this.pictureBoxseven.Name = "pictureBoxseven";
            this.pictureBoxseven.Size = new System.Drawing.Size(61, 60);
            this.pictureBoxseven.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxseven.TabIndex = 11;
            this.pictureBoxseven.TabStop = false;
            this.pictureBoxseven.Click += new System.EventHandler(this.pictureBoxseven_Click);
            // 
            // pictureBoxeight
            // 
            this.pictureBoxeight.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxeight.Image")));
            this.pictureBoxeight.Location = new System.Drawing.Point(99, 210);
            this.pictureBoxeight.Name = "pictureBoxeight";
            this.pictureBoxeight.Size = new System.Drawing.Size(62, 57);
            this.pictureBoxeight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxeight.TabIndex = 12;
            this.pictureBoxeight.TabStop = false;
            this.pictureBoxeight.Click += new System.EventHandler(this.pictureBoxeight_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(222, 46);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // marafonLabel
            // 
            this.marafonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.marafonLabel.Location = new System.Drawing.Point(784, 93);
            this.marafonLabel.Name = "marafonLabel";
            this.marafonLabel.Size = new System.Drawing.Size(185, 32);
            this.marafonLabel.TabIndex = 37;
            // 
            // labelMedical
            // 
            this.labelMedical.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMedical.Location = new System.Drawing.Point(784, 454);
            this.labelMedical.Name = "labelMedical";
            this.labelMedical.Size = new System.Drawing.Size(123, 45);
            this.labelMedical.TabIndex = 36;
            this.labelMedical.Text = "Медпункт";
            this.labelMedical.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxMedical
            // 
            this.pictureBoxMedical.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxMedical.Image")));
            this.pictureBoxMedical.Location = new System.Drawing.Point(713, 454);
            this.pictureBoxMedical.Name = "pictureBoxMedical";
            this.pictureBoxMedical.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxMedical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMedical.TabIndex = 35;
            this.pictureBoxMedical.TabStop = false;
            // 
            // labelInformation
            // 
            this.labelInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelInformation.Location = new System.Drawing.Point(784, 388);
            this.labelInformation.Name = "labelInformation";
            this.labelInformation.Size = new System.Drawing.Size(130, 45);
            this.labelInformation.TabIndex = 34;
            this.labelInformation.Text = "Информация";
            this.labelInformation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxInformation
            // 
            this.pictureBoxInformation.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxInformation.Image")));
            this.pictureBoxInformation.Location = new System.Drawing.Point(713, 386);
            this.pictureBoxInformation.Name = "pictureBoxInformation";
            this.pictureBoxInformation.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxInformation.TabIndex = 33;
            this.pictureBoxInformation.TabStop = false;
            // 
            // labelToilets
            // 
            this.labelToilets.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelToilets.Location = new System.Drawing.Point(784, 304);
            this.labelToilets.Name = "labelToilets";
            this.labelToilets.Size = new System.Drawing.Size(84, 45);
            this.labelToilets.TabIndex = 32;
            this.labelToilets.Text = "Туалет";
            this.labelToilets.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxTuilets
            // 
            this.pictureBoxTuilets.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTuilets.Image")));
            this.pictureBoxTuilets.Location = new System.Drawing.Point(713, 304);
            this.pictureBoxTuilets.Name = "pictureBoxTuilets";
            this.pictureBoxTuilets.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxTuilets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTuilets.TabIndex = 31;
            this.pictureBoxTuilets.TabStop = false;
            // 
            // labelEnergy
            // 
            this.labelEnergy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEnergy.Location = new System.Drawing.Point(784, 226);
            this.labelEnergy.Name = "labelEnergy";
            this.labelEnergy.Size = new System.Drawing.Size(217, 51);
            this.labelEnergy.TabIndex = 30;
            this.labelEnergy.Text = "Энергетич. батончики";
            this.labelEnergy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxEnergy
            // 
            this.pictureBoxEnergy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEnergy.Image")));
            this.pictureBoxEnergy.Location = new System.Drawing.Point(713, 226);
            this.pictureBoxEnergy.Name = "pictureBoxEnergy";
            this.pictureBoxEnergy.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxEnergy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEnergy.TabIndex = 29;
            this.pictureBoxEnergy.TabStop = false;
            // 
            // labelDrinks
            // 
            this.labelDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDrinks.Location = new System.Drawing.Point(784, 161);
            this.labelDrinks.Name = "labelDrinks";
            this.labelDrinks.Size = new System.Drawing.Size(94, 45);
            this.labelDrinks.TabIndex = 28;
            this.labelDrinks.Text = "Напитки";
            this.labelDrinks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBoxDrinks
            // 
            this.pictureBoxDrinks.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxDrinks.Image")));
            this.pictureBoxDrinks.Location = new System.Drawing.Point(713, 161);
            this.pictureBoxDrinks.Name = "pictureBoxDrinks";
            this.pictureBoxDrinks.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxDrinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDrinks.TabIndex = 27;
            this.pictureBoxDrinks.TabStop = false;
            // 
            // nameLabel
            // 
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel.Location = new System.Drawing.Point(708, 48);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(336, 45);
            this.nameLabel.TabIndex = 26;
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Map
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 654);
            this.Controls.Add(this.marafonLabel);
            this.Controls.Add(this.labelMedical);
            this.Controls.Add(this.pictureBoxMedical);
            this.Controls.Add(this.labelInformation);
            this.Controls.Add(this.pictureBoxInformation);
            this.Controls.Add(this.labelToilets);
            this.Controls.Add(this.pictureBoxTuilets);
            this.Controls.Add(this.labelEnergy);
            this.Controls.Add(this.pictureBoxEnergy);
            this.Controls.Add(this.labelDrinks);
            this.Controls.Add(this.pictureBoxDrinks);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBoxeight);
            this.Controls.Add(this.pictureBoxseven);
            this.Controls.Add(this.pictureBoxsix);
            this.Controls.Add(this.pictureBoxfifth);
            this.Controls.Add(this.pictureBoxforth);
            this.Controls.Add(this.pictureBoxthird);
            this.Controls.Add(this.pictureBoxsecond);
            this.Controls.Add(this.pictureBoxfirst);
            this.Controls.Add(this.pictureBoxStart3);
            this.Controls.Add(this.pictureBoxStart2);
            this.Controls.Add(this.pictureBoxStart1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Map";
            this.Text = "Карта";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxsecond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxthird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxforth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfifth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxsix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxseven)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBoxStart1;
        private System.Windows.Forms.PictureBox pictureBoxStart2;
        private System.Windows.Forms.PictureBox pictureBoxStart3;
        private System.Windows.Forms.PictureBox pictureBoxfirst;
        private System.Windows.Forms.PictureBox pictureBoxsecond;
        private System.Windows.Forms.PictureBox pictureBoxthird;
        private System.Windows.Forms.PictureBox pictureBoxforth;
        private System.Windows.Forms.PictureBox pictureBoxfifth;
        private System.Windows.Forms.PictureBox pictureBoxsix;
        private System.Windows.Forms.PictureBox pictureBoxseven;
        private System.Windows.Forms.PictureBox pictureBoxeight;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label marafonLabel;
        private System.Windows.Forms.Label labelMedical;
        private System.Windows.Forms.PictureBox pictureBoxMedical;
        private System.Windows.Forms.Label labelInformation;
        private System.Windows.Forms.PictureBox pictureBoxInformation;
        private System.Windows.Forms.Label labelToilets;
        private System.Windows.Forms.PictureBox pictureBoxTuilets;
        private System.Windows.Forms.Label labelEnergy;
        private System.Windows.Forms.PictureBox pictureBoxEnergy;
        private System.Windows.Forms.Label labelDrinks;
        private System.Windows.Forms.PictureBox pictureBoxDrinks;
        private System.Windows.Forms.Label nameLabel;
    }
}