﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PasswordChecker_Куделя_Никита;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordChecker_Куделя_Никита.Tests
{
    [TestClass()]
    public class PasswordCheckerTests
    {
        [TestMethod()]
        public void Check_8Symbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASqw12$$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_4Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "Aq1$";

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_30Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqwe123$ASDqwe 123SASDqwe 123S";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithDigits_ReturnTrue() //с цифрами
        {
            // Arrange.
            string password = "ASDqwe1$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithoutDigits_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqweASD$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithSpecSymbols_ReturnTrue()
        {
            // Arrange.
            string password = "Aqwel23$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithoutSpecSymbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqwe123";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithCapsSymbols_ReturnTrue()
        {
            // Arrange.
            string password = "Aqwel23$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithoutCapsSymbols_ReturnFalse()
        {
            // Arrange.
            string password = "asdqwel23$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithLowerSymbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASDql23$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithoutLowerSymbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDQWE123S";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            //Assert.
            Assert.AreEqual(expected, actual);
        }
    }
}