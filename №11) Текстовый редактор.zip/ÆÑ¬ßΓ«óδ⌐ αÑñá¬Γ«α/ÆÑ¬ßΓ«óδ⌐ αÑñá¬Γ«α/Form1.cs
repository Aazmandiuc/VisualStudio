﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Текстовый_редактор
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) //Проверяем был ли выбран файл
            {
                richTextBox.Clear(); //Очищаем richTextBox
                openFileDialog1.Filter = "Text Files (*.txt)|*.txt";
                //Указываем что нас интересуют только текстовые файлы

                string fileName = openFileDialog1.FileName;
                //получаем наименование файл и путь к нему.

                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251));
                //Передаем содержимое файла в richTextBox
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt";//Задаем доступные расширения
            saveFileDialog1.DefaultExt = ".txt"; //Задаем расширение по умолчанию
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            //Проверяем подтверждение сохранения информации
            {
                var name = saveFileDialog1.FileName; //Задаем имя файлу
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251));
                //Записываем в файл содержимое textBox с кодировкой 1251
            }
            richTextBox.Clear();

        }

        private void поЦентруToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
            richTextBox.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
            richTextBox.DeselectAll(); //Отмена выделения
        }

        private void поЛевомуКраюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
            richTextBox.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Left;
            richTextBox.DeselectAll(); //Отмена выделения
        }

        private void поПравомуКраюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
            richTextBox.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Right;
            richTextBox.DeselectAll(); //Отмена выделения
        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                richTextBox.Cut();
        }

        private void button_Cut_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                richTextBox.Cut();
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
                richTextBox.Copy();
        }

        private void button_Copy_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
                richTextBox.Copy();
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
                richTextBox.Paste();
        }

        private void button_Paste_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
                richTextBox.Paste();
        }

        private void очиститьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Text = "";
            richTextBox.Clear();
        }

        private void button_Clear_Click(object sender, EventArgs e)
        {
            richTextBox.Text = "";
            richTextBox.Clear();
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) //Проверяем был ли выбран файл
            {
                richTextBox.Clear(); //Очищаем richTextBox
                openFileDialog1.Filter = "Text Files (*.txt)|*.txt";
                //Указываем что нас интересуют только текстовые файлы

                string fileName = openFileDialog1.FileName;
                //получаем наименование файл и путь к нему.

                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251));
                //Передаем содержимое файла в richTextBox
            }
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt";//Задаем доступные расширения
            saveFileDialog1.DefaultExt = ".txt"; //Задаем расширение по умолчанию
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            //Проверяем подтверждение сохранения информации
            {
                var name = saveFileDialog1.FileName; //Задаем имя файлу
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251));
                //Записываем в файл содержимое textBox с кодировкой 1251
            }
            richTextBox.Clear();
        }
    }
}