﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI_Куделя_Никита
{
    public partial class Form1 : Form
    {
        float ind; // индекс
        float r; // рост
        float v; // вес
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            r = float.Parse(rost.Text);
            v = float.Parse(ves.Text);
            r = r / 100;
            ind = v / (r * r);
            index.Text = ind.ToString("N");
            trackBar1.Value = (int)ind;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ves.Text = null;
            rost.Text = null;
            index.Text = null;
            trackBar1.Value = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }
    }
}
