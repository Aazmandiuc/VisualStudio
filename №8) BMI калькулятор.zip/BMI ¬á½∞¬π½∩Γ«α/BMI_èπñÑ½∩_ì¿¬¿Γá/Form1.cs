﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI_Куделя_Никита
{
    public partial class Form1 : Form
    {
        float ind; // индекс
        float r; // рост
        float v; // вес
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            r = float.Parse(rost.Text);
            v = float.Parse(ves.Text);
            r = r / 100;
            ind = v / (r * r);
            index.Text = ind.ToString("N");
            trackBar1.Value = (int)ind;

            if (ind < 10)
            { trackBar1.Value = 10; label2.Text = "Недостаточный"; }

            if (ind < 18.5 && ind >= 10)
            { trackBar1.Value = Convert.ToInt32(ind); label2.Text = "Недостаточный"; }

            if (ind >= 18.5 && ind <= 24.9)
            { trackBar1.Value = Convert.ToInt32(ind); label2.Text = "Здоровый"; }

            if (ind <= 30 && ind > 24.9)
            { trackBar1.Value = Convert.ToInt32(ind); label2.Text = "Избыточный"; }

            if (ind > 30 && ind < 35)
            { trackBar1.Value = Convert.ToInt32(ind); label2.Text = "Ожирение"; }

            if (ind > 35)
            { trackBar1.Value = 35; label2.Text = "Ожирение"; }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            ves.Text = null;
            rost.Text = null;
            index.Text = null;
            trackBar1.Value = 0;
            label2.Text = null;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

    }
}
