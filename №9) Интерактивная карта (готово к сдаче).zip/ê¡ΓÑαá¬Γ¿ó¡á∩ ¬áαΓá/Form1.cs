﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Интерактивная_карта
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            clear();
        }

        private void pictureBoxStart1_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 1";
            marafonLabel.Text = "Samba full marafon";
            clear();
        }

        private void pictureBoxfirst_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МЦК Лужники";
            marafonLabel.Text = "Samba full marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
        }

        private void pictureBoxsecond_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Новодевичей монастырь";
            marafonLabel.Text = "Samba full marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        private void pictureBoxthird_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Киевская";
            marafonLabel.Text = "Samba full marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBoxforth_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МИД";
            marafonLabel.Text = "Samba full marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            
        }

        private void pictureBoxfifth_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Парк Горького";
            marafonLabel.Text = "Samba full marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxInformation.Location = new Point(698, 404); labelInformation.Location = new Point(769, 404);
        }

        private void pictureBoxsix_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Здание РАН";
            marafonLabel.Text = "Jongo Half Marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBoxseven_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Воробьёвы горы";
            marafonLabel.Text = "Jongo Half Marafon";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        private void pictureBoxeight_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Стадион Лужники";
            marafonLabel.Text = "Capoiera Fun Run 5km";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        //снова делает все невидимыми
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }

        private void pictureBoxStart2_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 2";
            marafonLabel.Text = "Jongo Half Marafon";
            clear();
        }

        private void pictureBoxStart3_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 3";
            marafonLabel.Text = "Capoiera Fun Run 5km";
            clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "ФИНИШ!!!";
            clear();
        }
    }
}
