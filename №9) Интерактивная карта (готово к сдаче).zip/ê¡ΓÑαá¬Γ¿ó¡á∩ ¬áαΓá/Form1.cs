﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Интерактивная_карта
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            clear();
        }

        private void pictureBoxStart1_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Первый старт гонки";
            marafonLabel.Text = "Полный марафон по самбо";
            clear();
        }

        private void pictureBoxfirst_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МЦК Лужники";
            marafonLabel.Text = "Полный марафон по самбо";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
        }

        private void pictureBoxsecond_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Новодевичей монастырь";
            marafonLabel.Text = "Полный марафон по самбо";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        private void pictureBoxthird_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Киевская";
            marafonLabel.Text = "Полный марафон по самбо";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBoxforth_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МИД";
            marafonLabel.Text = "Полный марафон по самбо";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            
        }

        private void pictureBoxfifth_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Парк Горького";
            marafonLabel.Text = "Полный марафон по самбо";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxInformation.Location = new Point(698, 404); labelInformation.Location = new Point(769, 404);
        }

        private void pictureBoxsix_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Здание РАН";
            marafonLabel.Text = "Полумарафон Джонго";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBoxseven_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Воробьёвы горы";
            marafonLabel.Text = "Полумарафон Джонго";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        private void pictureBoxeight_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Стадион Лужники";
            marafonLabel.Text = "Весёлая пробежка по капоэйре на 5 км";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 492); labelInformation.Location = new Point(769, 494);
        }

        //снова делает все невидимыми
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }

        private void pictureBoxStart2_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Второй старт гонки";
            marafonLabel.Text = "Полумарафон Джонго";
            clear();
        }

        private void pictureBoxStart3_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Третий старт гонки";
            marafonLabel.Text = "Весёлая пробежка по капоэйре на 5 км";
            clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "ФИНИШ!!!";
            clear();
        }
    }
}
